rm(list=ls())#clear Global Environment
setwd("D:/桌面/SCI论文写作与绘图/R语言绘图/代码复现/nature文章原图复现系列/代码/散点图+均值+显著性")
#加载包
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(dplyr) # A Grammar of Data Manipulation
library(ggsignif) # Significance Brackets for 'ggplot2'

# 加载示例数据
data <- read.table("data.txt",check.names = T,header = 1)
data$group <- factor(data$group,levels = c("CRISPR-ctrl","Trp22-KO"))
#计算均值并指定其在x轴上的位置
data %>% 
  group_by(group) %>% 
  summarise(mean_value=mean(value)) %>% 
  bind_cols(x=c(1,2))-> df1

##绘图
ggplot(data,aes(group,value))+
  geom_jitter(size=5,aes(fill=group),color="black",width = 0.08,shape=21)+
  geom_segment(data=df1,aes(x=x-0.25,xend=x+0.25,y=mean_value,yend=mean_value),
               color="black",linewidth=1.5)+
  geom_signif(comparisons = list(c("CRISPR-ctrl","Trp22-KO")),
              map_signif_level=T, 
              tip_length=0, 
              y_position = 102, 
              size=1, textsize = 7, 
              test = "t.test")+
  theme_classic()+
  theme(legend.position = "none",
        axis.line = element_line(linewidth = 1),
        axis.text.y = element_text(color="black",size = 15),
        axis.text.x = element_text(color="black",size = 16,angle = 45,hjust = 1,vjust = 1),
        axis.title.y = element_text(color="black",size = 18),
        axis.ticks.y = element_line(size=1),
        axis.ticks.x = element_blank(),
        plot.background = element_blank(),
        plot.title = element_text(color="black",size = 20))+
  scale_fill_manual(values = c("#00c000","#a0ffa0"))+
  labs(x=NULL,y="Percentage in arrest",title = "Arrest coefficier")+
  scale_y_continuous(limits = c(-1,110),breaks = seq(0, 100, len = 3))

