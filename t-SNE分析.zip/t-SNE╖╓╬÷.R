###科研后花园########
#author:wzs
#data:2023/5/23


#设置工作环境
rm(list=ls())
setwd("D:/桌面/SCI论文写作与绘图/R语言绘图/数据分析及可视化/t-SNE分析")

#加载R包
library(Rtsne)
library(ggplot2)
library(microeco)
#加载数据
data(sample_info_16S)
data(otu_table_16S)
sample_info_16S <- as.data.frame(sample_info_16S)#确保行名是样本名称，重要
otu_table_16S <- as.data.frame(otu_table_16S)
#由于排序分析函数所需数据格式原因，需要对数据进行转置
otu <- t(otu_table_16S)
#去除低质量OTU
otu <- otu[rowSums(otu) > 0, ] 
# 进行t-SNE分析
tsne <- Rtsne(otu,pca=FALSE,dims=2,perplexity=25,theta=0.0)
head(tsne$Y)
# 提取tsne值
df <- data.frame(tsne$Y)
#给df添加samp1es变量
df$SampleID <- row.names(sample_info_16S)
#分组文件
group <- sample_info_16S
#将绘图数据和分组合并
df <- merge(df,group,by="SampleID")
head(df)
#绘图
color=c("#1597A5","#FFC24B","#FEB3AE")#颜色变量
p1<-ggplot(data=df,aes(x=X1,y=X2))+#指定数据、X轴、Y轴，颜色
  theme_bw()+#主题设置
  geom_point(aes(fill=Group),size=3,color="black",shape=21,alpha=0.7)+#绘制点图并设定大小
  theme(panel.grid = element_blank())+
  geom_vline(xintercept = 0,lty="dashed")+
  geom_hline(yintercept = 0,lty="dashed")+
  labs(x=paste0("tSNE1 "),
       y=paste0("tSNE2 "))+
  scale_fill_manual(values = color)+
  theme(axis.title.x=element_text(size=12),#修改X轴标题文本
        axis.title.y=element_text(size=12,angle=90),#修改y轴标题文本
        axis.text.y=element_text(size=10),#修改x轴刻度标签文本
        axis.text.x=element_text(size=10),#修改y轴刻度标签文本
        panel.grid=element_blank())#隐藏网格线
p1
