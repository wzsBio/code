###科研后花园########
#author:wzs
#data:2023/5/21


#设置工作环境
rm(list=ls())
setwd("D:/桌面/SCI论文写作与绘图/R语言绘图/数据分析及可视化/UMAP分析")

#加载R包
library(umap)
library(ggplot2)
library(vegan)

#加载数据
otu_raw <- read.table(file="otu.txt",sep="\t",header=T,check.names=FALSE ,row.names=1)
#由于排序分析函数所需数据格式原因，需要对数据进行转置
otu <- t(otu_raw)
#去除低质量OTU
otu <- otu[rowSums(otu) > 0, ] 
#进行hellinger标准化,亦可进行总和标准化、z-score标准化等
otu <- decostand(otu, method="hellinger")
#运用UMAP算法将OTU表的样品向量嵌入到二维空间中
umap <- umap(otu,n_neighbors = 10)
head(umap$layout)
# 提取umap值
df <- data.frame(umap$layout)
#给df添加samp1es变量
df$samples <- row.names(df)
#读入分组文件
group <- read.table("group.txt", sep='\t', header=T)
#修改列名
colnames(group) <- c("samples","group")
#将绘图数据和分组合并
df <- merge(df,group,by="samples")
head(df)
#绘图
color=c("#1597A5","#FFC24B","#FEB3AE")#颜色变量
p1<-ggplot(data=df,aes(x=X1,y=X2,
                       color=group))+#指定数据、X轴、Y轴，颜色
  theme_bw()+#主题设置
  geom_point(size=3)+#绘制点图并设定大小
  theme(panel.grid = element_blank())+
  geom_vline(xintercept = 0,lty="dashed")+
  geom_hline(yintercept = 0,lty="dashed")+
  labs(x=paste0("UMAP1 "),
       y=paste0("UMAP2 "))+
  scale_color_manual(values = color) +#点的颜色设置
  scale_fill_manual(values = c("#1597A5","#FFC24B","#FEB3AE"))+
  theme(axis.title.x=element_text(size=12),#修改X轴标题文本
        axis.title.y=element_text(size=12,angle=90),#修改y轴标题文本
        axis.text.y=element_text(size=10),#修改x轴刻度标签文本
        axis.text.x=element_text(size=10),#修改y轴刻度标签文本
        panel.grid=element_blank())#隐藏网格线
p1


#####拓展
#以microeco包中的示例数据为例
library(microeco)
data(sample_info_16S)
data(otu_table_16S)
sample_info_16S <- as.data.frame(sample_info_16S)#确保行名是样本名称，重要
otu_table_16S <- as.data.frame(otu_table_16S)
#由于排序分析函数所需数据格式原因，需要对数据进行转置
otu <- t(otu_table_16S)
#去除低质量OTU
otu <- otu[rowSums(otu) > 0, ] 
#进行hellinger标准化,亦可进行总和标准化、z-score标准化等
otu <- decostand(otu, method="hellinger")
#运用UMAP算法将OTU表的样品向量嵌入到二维空间中
umap <- umap(otu,n_neighbors = 10)
head(umap$layout)
# 提取umap值
df <- data.frame(umap$layout)
#给df添加samp1es变量
df$SampleID <- row.names(df)
#分组文件
group <- sample_info_16S
#将绘图数据和分组合并
df <- merge(df,group,by="SampleID")
head(df)
#绘图
color=c("#1597A5","#FFC24B","#FEB3AE")#颜色变量
p1<-ggplot(data=df,aes(x=X1,y=X2))+#指定数据、X轴、Y轴，颜色
  theme_bw()+#主题设置
  geom_point(aes(fill=Group),size=3,color="black",shape=21,alpha=0.7)+#绘制点图并设定大小
  theme(panel.grid = element_blank())+
  geom_vline(xintercept = 0,lty="dashed")+
  geom_hline(yintercept = 0,lty="dashed")+
  labs(x=paste0("UMAP1 "),
       y=paste0("UMAP2 "))+
  scale_fill_manual(values = color)+
  theme(axis.title.x=element_text(size=12),#修改X轴标题文本
        axis.title.y=element_text(size=12,angle=90),#修改y轴标题文本
        axis.text.y=element_text(size=10),#修改x轴刻度标签文本
        axis.text.x=element_text(size=10),#修改y轴刻度标签文本
        panel.grid=element_blank())#隐藏网格线
p1
